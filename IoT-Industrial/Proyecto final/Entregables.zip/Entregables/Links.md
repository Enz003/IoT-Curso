## Wokwi
### Carrusel 1
https://wokwi.com/projects/465586243161614337
### Carrusel 2
https://wokwi.com/projects/465586444655995905
### Carrusel 3
https://wokwi.com/projects/465853575364581377

## Simulacion
https://drive.google.com/file/d/1s5rcp9bt4nNTJcPsSfUvVg0EjEqfXPRn/view?usp=sharing

